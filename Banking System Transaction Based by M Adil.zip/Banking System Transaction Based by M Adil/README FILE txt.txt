# Banking System (Transaction Validation) By M Adil

## Project Overview
This project, titled **Banking System (Transaction Validation)**, implements a transaction validation system using formal methods and the Z3 theorem prover. It is designed to validate banking transactions while ensuring constraints such as non-negative balance and unique transaction IDs. The system is interactive and allows users to add, remove, and validate transactions dynamically.

## Features
- **Add Transactions**: Add new transactions with unique IDs and positive amounts.
- **Remove Transactions**: Remove existing transactions by their IDs.
- **Constraint Validation**: Uses Z3 to ensure the balance remains non-negative and all constraints are satisfied.
- **Interactive Menu**: User-friendly interface for managing transactions.

## Project Structure
```
Banking System (Transaction Validation)
|
|-- Code
|   |-- Banking System Z3.py  # Main script implementing the system
|
|-- Documentation
|   |-- M Adil reg no 2021 gu 820 Documentation.docx  # Detailed project documentation
|
|-- Screenshots
    |-- 1.png  # Screenshot of the system in action
    |-- 2.png  # Screenshot of the system in action
    |-- 3.png  # Screenshot of the system in action
    |-- 4.png  # Screenshot of the system in action
```

## Requirements
- Python 3.8 or higher
- Z3 SMT Solver Python bindings

## Installation
1. Clone the repository or download the zip file.
2. Install the Z3 Python bindings:
   ```bash
   pip install z3-solver
   ```
3. Navigate to the `Code` directory and run the main script:
   ```bash
   python "Banking System Z3.py"
   ```

## Usage
1. Start the program by running the script.
2. Use the interactive menu to:
   - Add new transactions by providing a unique ID and amount.
   - Remove existing transactions by their IDs.
   - Check if all constraints are satisfied.
3. View real-time updates and validation results.

## Screenshots
Below are examples of the system in action:

![Screenshot 1](Screenshots/1.png)
![Screenshot 2](Screenshots/2.png)
![Screenshot 3](Screenshots/3.png)
![Screenshot 4](Screenshots/4.png)

## Documentation
For a detailed explanation of the project's objectives, implementation, and results, refer to the documentation file:
`Documentation/M Adil reg no 2021 gu 820 Documentation.docx`

## Author
- **M. Adil**  

## License
This project is licensed under the MIT License.
